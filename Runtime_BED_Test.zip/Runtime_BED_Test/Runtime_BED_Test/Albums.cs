﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Runtime_BED_Test
{
	public class Albums
	{
		public string UserId { get; set; }
		public string Id { get; set; }
		public string Title { get; set; }
	}
}
