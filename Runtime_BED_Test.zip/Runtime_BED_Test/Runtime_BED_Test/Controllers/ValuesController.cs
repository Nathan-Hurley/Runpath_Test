﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Runtime_BED_Test.Controllers
{
	[Route("api/values")]
	[ApiController]
	public class ValuesController : ControllerBase
	{
		private readonly ValuesRepository valuesRepository;

		public ValuesController()
		{
			valuesRepository = new ValuesRepository();
		}

		// GET api/values/{userId}
		[HttpGet("{userId}")]
		public ActionResult<List<object>> Get(string userId)
		{
			List<Albums> albums = valuesRepository.GetAlbumsByUserId(userId);
			List<Photos> photos = valuesRepository.GetPhotosById(albums);

			List<object> result = new List<object>
			{
				albums,
				photos
			};

			return result;
		}
	}
}
