﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace Runtime_BED_Test.Controllers
{
	public class ValuesRepository
	{
		private readonly WebClient wc = new WebClient();
		
		/// <summary>
		/// Gets and filters the album data by user id
		/// </summary>
		/// <param name="userId"></param>
		/// <returns>List of Albums</returns>
		public List<Albums> GetAlbumsByUserId(string userId)
		{
			// Get the album data
			byte[] albumsRaw = wc.DownloadData("http://jsonplaceholder.typicode.com/albums");
			string albumsData = System.Text.Encoding.UTF8.GetString(albumsRaw);
			List<Albums> albumsJson = JsonConvert.DeserializeObject<List<Albums>>(albumsData);

			// Filter data by user id
			List<Albums> filteredAlbums = albumsJson.Where(x => x.UserId == userId).ToList();

			return filteredAlbums;
		}

		/// <summary>
		/// Gets and filters the photo data by id from albums
		/// </summary>
		/// <param name="albums"></param>
		/// <returns>List of photos</returns>
		public List<Photos> GetPhotosById(List<Albums> albums)
		{
			// Get the photo data
			byte[] photoRaw = wc.DownloadData("http://jsonplaceholder.typicode.com/photos");
			string photosData = System.Text.Encoding.UTF8.GetString(photoRaw);
			List<Photos> photosJson = JsonConvert.DeserializeObject<List<Photos>>(photosData);

			// Filter data by id
			List<Photos> filteredPhotos = new List<Photos>();
			foreach (Albums album in albums)
			{
				List<Photos> albumList = photosJson.Where(x => x.Id == album.Id).ToList();
				filteredPhotos.AddRange(albumList);
			}

			return filteredPhotos;
		}
	}
}
